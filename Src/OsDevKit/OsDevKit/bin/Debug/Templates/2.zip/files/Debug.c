#include <system.h>

void StartDebugger()
{
    Serial_Begin(COM1);
}

void DebugWrite(string a) 
{
   Serial_WriteString(a);
}