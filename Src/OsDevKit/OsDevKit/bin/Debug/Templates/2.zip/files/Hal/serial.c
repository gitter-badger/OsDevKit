#include <system.h>
 
int PORT;

void Serial_Begin(int ComPort){
   PORT = ComPort;
   outb(PORT + 1, 0x00);    // Disable all interrupts
   outb(PORT + 3, 0x80);    // Enable DLAB (set baud rate divisor)
   outb(PORT + 0, 0x03);    // Set divisor to 3 (lo byte) 38400 baud
   outb(PORT + 1, 0x00);    //                  (hi byte)
   outb(PORT + 3, 0x03);    // 8 bits, no parity, one stop bit
   outb(PORT + 2, 0xC7);    // Enable FIFO, clear them, with 14-byte threshold
   outb(PORT + 4, 0x0B);    // IRQs enabled, RTS/DSR set
}

int serialReceived() {
   return inb(PORT + 5) & 1;
}
 
char Serial_ReadChar() {
   while (serialReceived() == 0);
   return inb(PORT);
}

int isTransmitEmpty() {
   return inb(PORT + 5) & 0x20;
}
 
void Serial_WriteChar(char a) {
   while (isTransmitEmpty() == 0);
   outb(PORT,a);
}

void Serial_WriteString(string a)
{
    while (*a != 0)
    {
        Serial_WriteChar(*a);
        a = a + 1;
    }
}