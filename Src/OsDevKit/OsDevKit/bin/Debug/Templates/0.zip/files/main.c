
void kmain (void* MultibootStructure)
{

}

